// Starting point
fun main(args: Array<String>)
{
   // You code here
    println("Hello")
}
