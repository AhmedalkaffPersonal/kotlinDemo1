import java.lang.Math.sqrt

fun main() {

    var x:Int = 0
    // I need to print numbers from 1 up to 10
    while (x < 10)
    {
        println(x)
        x+= 2
    }


}